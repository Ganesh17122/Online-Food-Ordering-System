-- Migration: create orders table with fields needed by the frontend
CREATE DATABASE IF NOT EXISTS greenplate;
USE greenplate;

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customerId INT NULL,
  customerName VARCHAR(255) NULL,
  restaurantId INT NOT NULL,
  deliveryAgentId INT NULL,
  items TEXT NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  deliveryAddress VARCHAR(500) NULL,
  isPreorder TINYINT(1) DEFAULT 0,
  scheduledDelivery DATETIME NULL,
  deliveryFeedback TEXT NULL,
  status VARCHAR(50) NOT NULL,
  orderDate DATETIME NOT NULL,
  INDEX (restaurantId),
  INDEX (customerId),
  INDEX (deliveryAgentId)
);
