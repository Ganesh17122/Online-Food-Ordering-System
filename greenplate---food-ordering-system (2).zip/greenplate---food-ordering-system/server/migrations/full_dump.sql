-- Full database dump for GreenPlate (development)
-- Create database and tables, then seed with mock data

SET FOREIGN_KEY_CHECKS = 0;

DROP DATABASE IF EXISTS `greenplate`;
CREATE DATABASE `greenplate` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `greenplate`;

-- USERS
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  phone VARCHAR(50) DEFAULT NULL,
  password VARCHAR(255),
  role VARCHAR(50) NOT NULL,
  avatar TEXT,
  location_lat DECIMAL(11,8) NULL,
  location_lng DECIMAL(11,8) NULL,
  location_timestamp BIGINT NULL
);

-- Passwords are stored as bcrypt hashes (development convenience).
-- The hash used below corresponds to the plaintext "password" (bcrypt, cost 10).
INSERT INTO users (id, name, email, phone, password, role, avatar) VALUES
(1, 'Alice Johnson', 'customer@example.com', NULL, '$2b$10$CwTycUXWue0Thq9StjUM0uJ8rR9EmzX0QHq7Y6sR1q7k2K/1pF2e', 'CUSTOMER', 'https://i.pravatar.cc/150?u=customer@example.com'),
(2, 'Bob Williams', 'delivery@example.com', '555-0101', '$2b$10$CwTycUXWue0Thq9StjUM0uJ8rR9EmzX0QHq7Y6sR1q7k2K/1pF2e', 'DELIVERY', 'https://i.pravatar.cc/150?u=delivery@example.com'),
(3, 'Charlie Brown', 'admin@example.com', NULL, '$2b$10$CwTycUXWue0Thq9StjUM0uJ8rR9EmzX0QHq7Y6sR1q7k2K/1pF2e', 'ADMIN', 'https://i.pravatar.cc/150?u=admin@example.com'),
(4, 'David Smith', 'delivery2@example.com', '555-0102', '$2b$10$CwTycUXWue0Thq9StjUM0uJ8rR9EmzX0QHq7Y6sR1q7k2K/1pF2e', 'DELIVERY', 'https://i.pravatar.cc/150?u=delivery2@example.com');

-- RESTAURANTS
DROP TABLE IF EXISTS restaurants;
CREATE TABLE restaurants (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  cuisine VARCHAR(100),
  rating DECIMAL(2,1),
  deliveryTime INT,
  image TEXT
);

INSERT INTO restaurants (id, name, cuisine, rating, deliveryTime, image) VALUES
(1, 'The Green Leaf', 'Italian', 4.8, 25, 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=2070&auto=format&fit=crop'),
(2, 'Spicy Dragon', 'Chinese', 4.5, 30, 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=1974&auto=format&fit=crop'),
(3, 'Burger Barn', 'American', 4.7, 20, 'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?q=80&w=2070&auto=format&fit=crop'),
(4, 'Sushi Central', 'Japanese', 4.9, 40, 'https://images.unsplash.com/photo-1579532537598-459ecdaf39cc?q=80&w=2070&auto=format&fit=crop'),
(5, 'Taste of India', 'Indian', 4.9, 35, 'https://images.unsplash.com/photo-1552566626-52f8b828add9?q=80&w=2070&auto=format&fit=crop');

-- MENU ITEMS (one table for all restaurants)
DROP TABLE IF EXISTS menu_items;
CREATE TABLE menu_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  restaurantId INT NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  image TEXT,
  category VARCHAR(100),
  isAvailable TINYINT(1) DEFAULT 1,
  FOREIGN KEY (restaurantId) REFERENCES restaurants(id) ON DELETE CASCADE
);

INSERT INTO menu_items (id, restaurantId, name, description, price, image, category, isAvailable) VALUES
(101, 1, 'Margherita Pizza', 'Classic cheese and tomato pizza.', 12.99, 'https://images.unsplash.com/photo-1594007654729-407eedc4be65?q=80&w=1928&auto=format&fit=crop', 'Pizza', 1),
(102, 1, 'Pasta Carbonara', 'Creamy pasta with bacon.', 15.50, 'https://images.unsplash.com/photo-1608797223204-a15d9c2a61da?q=80&w=1974&auto=format&fit=crop', 'Pasta', 1),
(103, 1, 'Tiramisu', 'Coffee-flavoured Italian dessert.', 7.00, 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?q=80&w=2072&auto=format&fit=crop', 'Desserts', 1),
(104, 1, 'Garlic Bread', 'Toasted bread with garlic butter.', 5.50, 'https://images.unsplash.com/photo-1623334055234-b2674e253c33?q=80&w=2070&auto=format&fit=crop', 'Sides', 0),
(105, 1, 'Pepperoni Pizza', 'Pizza with spicy pepperoni.', 14.50, 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?q=80&w=1981&auto=format&fit=crop', 'Pizza', 1),

(201, 2, 'Sweet & Sour Chicken', 'Crispy chicken with sweet and sour sauce.', 14.00, 'https://images.unsplash.com/photo-1607329715180-8a4a7ff903c8?q=80&w=1935&auto=format&fit=crop', 'Main', 1),
(202, 2, 'Vegetable Fried Rice', 'Stir-fried rice with fresh vegetables.', 9.50, 'https://images.unsplash.com/photo-1616450257904-87d228b348d6?q=80&w=2070&auto=format&fit=crop', 'Sides', 1),
(203, 2, 'Spring Rolls', 'Crispy rolls with vegetable filling.', 6.00, 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?q=80&w=1974&auto=format&fit=crop', 'Appetizers', 1),
(204, 2, 'Kung Pao Shrimp', 'Spicy stir-fried shrimp with peanuts.', 16.50, 'https://images.unsplash.com/photo-1593921714848-a53c3b018b14?q=80&w=2070&auto=format&fit=crop', 'Main', 0),
(205, 2, 'Chow Mein Noodles', 'Stir-fried noodles with vegetables.', 12.00, 'https://images.unsplash.com/photo-1585032226651-759b368d7246?q=80&w=1994&auto=format&fit=crop', 'Main', 1),

(301, 3, 'Classic Cheeseburger', 'Beef patty with cheese, lettuce, and tomato.', 11.99, 'https://images.unsplash.com/photo-1551987840-f62d9c0252a2?q=80&w=2070&auto=format&fit=crop', 'Burgers', 1),
(302, 3, 'Loaded Fries', 'Fries with cheese, bacon, and sour cream.', 8.50, 'https://images.unsplash.com/photo-1598679253443-4b53b51b32b3?q=80&w=2070&auto=format&fit=crop', 'Sides', 1),
(303, 3, 'BBQ Bacon Burger', 'Beef patty with bacon, BBQ sauce, and onion rings.', 13.50, 'https://images.unsplash.com/photo-1607013251379-e6eecfffe234?q=80&w=1974&auto=format&fit=crop', 'Burgers', 1),
(304, 3, 'Chocolate Milkshake', 'Rich chocolate milkshake.', 6.00, 'https://images.unsplash.com/photo-1625862143015-88574775d713?q=80&w=1964&auto=format&fit=crop', 'Drinks', 1),

(401, 4, 'California Roll', 'Crab, avocado, and cucumber.', 10.00, 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?q=80&w=2070&auto=format&fit=crop', 'Rolls', 1),
(402, 4, 'Salmon Nigiri', 'Fresh salmon over rice.', 5.00, 'https://images.unsplash.com/photo-1611142037388-a5951334c264?q=80&w=2070&auto=format&fit=crop', 'Nigiri', 1),
(403, 4, 'Spicy Tuna Roll', 'Tuna with spicy mayo.', 11.00, 'https://images.unsplash.com/photo-1622722234994-c13f8373f139?q=80&w=2070&auto=format&fit=crop', 'Rolls', 1),
(404, 4, 'Miso Soup', 'Traditional Japanese soup with tofu and seaweed.', 3.50, 'https://images.unsplash.com/photo-1569562211242-a396201b132e?q=80&w=1974&auto=format&fit=crop', 'Soups', 1),

(501, 5, 'Chicken Biryani', 'Aromatic rice dish with chicken.', 15.99, 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?q=80&w=1974&auto=format&fit=crop', 'Main Courses', 1),
(502, 5, 'Paneer Butter Masala', 'Cottage cheese in a creamy tomato sauce.', 13.50, 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?q=80&w=2070&auto=format&fit=crop', 'Vegetarian', 1),
(503, 5, 'Garlic Naan', 'Soft flatbread with garlic.', 4.00, 'https://images.unsplash.com/photo-1631292784024-76b3a1a1b3a3?q=80&w=1974&auto=format&fit=crop', 'Breads', 1),
(504, 5, 'Samosa', 'Fried pastry with a savory filling.', 5.50, 'https://images.unsplash.com/photo-1625343114893-35f52174c203?q=80&w=2070&auto=format&fit=crop', 'Appetizers', 0),
(505, 5, 'Mango Lassi', 'Cool and refreshing yogurt drink.', 4.50, 'https://images.unsplash.com/photo-1567206563064-6f60f40a2b57?q=80&w=1974&auto=format&fit=crop', 'Drinks', 1);

-- ORDERS table
DROP TABLE IF EXISTS orders;
CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customerId INT NULL,
  customerName VARCHAR(255) NULL,
  restaurantId INT NOT NULL,
  deliveryAgentId INT NULL,
  items TEXT NOT NULL, -- JSON text
  total DECIMAL(10,2) NOT NULL,
  deliveryAddress VARCHAR(500) NULL,
  isPreorder TINYINT(1) DEFAULT 0,
  scheduledDelivery DATETIME NULL,
  deliveryFeedback TEXT NULL, -- JSON text like {"rating":4,"comment":"..."}
  deliveryReport TEXT NULL,
  status VARCHAR(50) NOT NULL,
  orderDate DATETIME NOT NULL,
  INDEX (restaurantId),
  INDEX (customerId),
  INDEX (deliveryAgentId)
);

-- ORDER_ITEMS (normalized list of items per order; optional but useful)
DROP TABLE IF EXISTS order_items;
CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  orderId INT NOT NULL,
  menuItemId INT NULL,
  name VARCHAR(255),
  quantity INT DEFAULT 1,
  price DECIMAL(10,2),
  FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE
);

-- Seed ORDERS (from constants)
-- Order 1001
INSERT INTO orders (id, customerId, restaurantId, deliveryAgentId, items, total, deliveryAddress, isPreorder, status, orderDate)
VALUES (
  1001,
  1,
  1,
  2,
  '[{"menuItemId":101,"name":"Margherita Pizza","quantity":2,"price":12.99}]',
  25.98,
  '123 Green St, Cityville',
  0,
  'Delivered',
  '2023-10-26 10:00:00'
);

INSERT INTO order_items (orderId, menuItemId, name, quantity, price) VALUES
(1001, 101, 'Margherita Pizza', 2, 12.99);

-- Order 1002: set orderDate to NOW() - 10 minutes
INSERT INTO orders (id, customerId, restaurantId, deliveryAgentId, items, total, deliveryAddress, isPreorder, status, orderDate)
VALUES (
  1002,
  1,
  2,
  2,
  '[{"menuItemId":201,"name":"Sweet & Sour Chicken","quantity":1,"price":14.00},{"menuItemId":202,"name":"Vegetable Fried Rice","quantity":1,"price":9.5}]',
  23.50,
  '123 Green St, Cityville',
  0,

  'Out for Delivery',
  (NOW() - INTERVAL 10 MINUTE)
);

INSERT INTO order_items (orderId, menuItemId, name, quantity, price) VALUES
(1002, 201, 'Sweet & Sour Chicken', 1, 14.00),
(1002, 202, 'Vegetable Fried Rice', 1, 9.50);

-- Order 1003: scheduled for +1 day (preorder)
INSERT INTO orders (id, customerId, restaurantId, deliveryAgentId, items, total, deliveryAddress, isPreorder, scheduledDelivery, status, orderDate)
VALUES (
  1003,
  1,
  3,
  NULL,
  '[{"menuItemId":301,"name":"Classic Cheeseburger","quantity":1,"price":11.99}]',
  11.99,
  '123 Green St, Cityville',
  1,
  (NOW() + INTERVAL 1 DAY),
  'Confirmed',
  NOW()
);

INSERT INTO order_items (orderId, menuItemId, name, quantity, price) VALUES
(1003, 301, 'Classic Cheeseburger', 1, 11.99);

SET FOREIGN_KEY_CHECKS = 1;

-- End of dump
