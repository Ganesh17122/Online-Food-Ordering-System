-- Create messages table for persistence of in-app messages
DROP TABLE IF EXISTS messages;
CREATE TABLE messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fromId INT NOT NULL,
  toId INT NOT NULL,
  orderId INT NULL,
  text TEXT NOT NULL,
  timestamp DATETIME NOT NULL,
  INDEX (fromId),
  INDEX (toId),
  INDEX 