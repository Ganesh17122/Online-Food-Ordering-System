-- Migration: create users table for GreenPlate
CREATE DATABASE IF NOT EXISTS greenplate;
USE greenplate;

DROP TABLE IF EXISTS users;
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255),
  role VARCHAR(50) NOT NULL,
  avatar TEXT,
  location_lat DECIMAL(11,8) NULL,
  location_lng DECIMAL(11,8) NULL,
  location_timestamp BIGINT NULL
);

-- Example seed (bcrypt hash for plaintext "password")
INSERT INTO users (name, email, password, role, avatar) VALUES
('Alice Johnson', 'customer@example.com', '$2b$10$CwTycUXWue0Thq9StjUM0uJ8rR9EmzX0QHq7Y6sR1q7k2K/1pF2e', 'CUSTOMER', 'https://i.pravatar.cc/150?u=customer@example.com');
