# GreenPlate Server — MySQL (XAMPP) backend

This lightweight Express server connects to a MySQL database (XAMPP) and exposes a small API under `/api`.

Quick setup

1. Start XAMPP and make sure MySQL is running.
2. Create a database for the app (example SQL below).
3. In `server/`, create a `.env` from `.env.example` and set DB credentials (DB_USER, DB_PASSWORD, DB_NAME).
4. Run:

   ```powershell
   cd server; npm install
   npm start
   ```

Example SQL (run in phpMyAdmin or mysql CLI):

```sql
CREATE DATABASE IF NOT EXISTS greenplate;
USE greenplate;

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customerId INT NULL,
  customerName VARCHAR(255) NULL,
  restaurantId INT NOT NULL,
  deliveryAgentId INT NULL,
  items TEXT NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  deliveryAddress VARCHAR(500) NULL,
  isPreorder TINYINT(1) DEFAULT 0,
  scheduledDelivery DATETIME NULL,
  deliveryFeedback TEXT NULL,
  status VARCHAR(50) NOT NULL,
  orderDate DATETIME NOT NULL,
  INDEX (restaurantId),
  INDEX (customerId),
  INDEX (deliveryAgentId)
);
```

Or run the provided migration file at `server/migrations/create_orders.sql`:

```powershell
mysql -u root -p < server/migrations/create_orders.sql
```

API endpoints

- GET /api/ping — quick health check
- GET /api/orders — list orders (limits to 100 most recent)
- POST /api/orders — create an order; body should contain `customerName`, `restaurantId`, `items` (array), and `total`.

Notes

- This server uses `mysql2` with a connection pool. It expects the database to exist.
- For production you should secure DB credentials and add validation.
