import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import db from './db.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const port = process.env.PORT || 3001;

app.get('/api/ping', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.get('/api/orders', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM orders ORDER BY id DESC LIMIT 100');
    // return rows as-is (they will be mapped client-side to the frontend shape)
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

// Users endpoints
app.get('/api/users', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM users ORDER BY id ASC');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

app.post('/api/users', async (req, res) => {
  try {
    const { name, email, password = null, role = 'CUSTOMER', avatar = null, phone = null } = req.body;
    // Basic duplicate email check
    const [existing] = await db.query('SELECT id FROM users WHERE email = ? LIMIT 1', [email]);
    if (Array.isArray(existing) && existing.length > 0) {
      return res.status(409).json({ error: 'email_exists' });
    }

    const [result] = await db.query(
      'INSERT INTO users (name, email, password, role, avatar, phone) VALUES (?, ?, ?, ?, ?, ?)',
      [name, email, password, role, avatar, phone]
    );

    const [rows] = await db.query('SELECT * FROM users WHERE id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const {
      customerId = null,
      customerName = null,
      restaurantId,
      deliveryAgentId = null,
      items = [],
      total = 0,
      deliveryAddress = null,
      isPreorder = false,
      scheduledDelivery = null,
      deliveryFeedback = null,
      status = 'PENDING'
    } = req.body;

    const [result] = await db.query(
      `INSERT INTO orders (
        customerId, customerName, restaurantId, deliveryAgentId, items, total, deliveryAddress, isPreorder, scheduledDelivery, deliveryFeedback, status, orderDate
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        customerId,
        customerName,
        restaurantId,
        deliveryAgentId,
        JSON.stringify(items),
        total,
        deliveryAddress,
        isPreorder ? 1 : 0,
        scheduledDelivery,
        deliveryFeedback ? JSON.stringify(deliveryFeedback) : null,
        status
      ]
    );

    // Return the inserted row so client can reconcile IDs/dates if needed
    const [rows] = await db.query('SELECT * FROM orders WHERE id = ?', [result.insertId]);
    res.json(rows[0] || { id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

// Update an order (items, status, deliveryFeedback, deliveryReport, etc.)
app.put('/api/orders/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { items, total, status, deliveryFeedback, deliveryReport, deliveryAgentId, deliveryAddress, scheduledDelivery } = req.body;

    // Build partial update
    const fields = [];
    const values = [];
    if (typeof items !== 'undefined') { fields.push('items = ?'); values.push(JSON.stringify(items)); }
    if (typeof total !== 'undefined') { fields.push('total = ?'); values.push(total); }
    if (typeof status !== 'undefined') { fields.push('status = ?'); values.push(status); }
    if (typeof deliveryFeedback !== 'undefined') { fields.push('deliveryFeedback = ?'); values.push(deliveryFeedback ? JSON.stringify(deliveryFeedback) : null); }
    if (typeof deliveryReport !== 'undefined') { fields.push('deliveryReport = ?'); values.push(deliveryReport ? JSON.stringify(deliveryReport) : null); }
    if (typeof deliveryAgentId !== 'undefined') { fields.push('deliveryAgentId = ?'); values.push(deliveryAgentId); }
    if (typeof deliveryAddress !== 'undefined') { fields.push('deliveryAddress = ?'); values.push(deliveryAddress); }
    if (typeof scheduledDelivery !== 'undefined') { fields.push('scheduledDelivery = ?'); values.push(scheduledDelivery); }

    if (fields.length === 0) {
      return res.status(400).json({ error: 'no_fields' });
    }

    const sql = `UPDATE orders SET ${fields.join(', ')} WHERE id = ?`;
    values.push(id);
    await db.query(sql, values);
    const [rows] = await db.query('SELECT * FROM orders WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

// Cancel/delete an order: mark as CANCELLED
app.delete('/api/orders/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    await db.query('UPDATE orders SET status = ? WHERE id = ?', ['Cancelled', id]);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

// --- Restaurants endpoints ---
app.get('/api/restaurants', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM restaurants ORDER BY id ASC');
    const restaurants = [];
    for (const r of rows) {
      const [menuRows] = await db.query('SELECT * FROM menu_items WHERE restaurantId = ? ORDER BY id ASC', [r.id]);
      restaurants.push({ ...r, menu: Array.isArray(menuRows) ? menuRows.map(m => ({
        id: m.id,
        name: m.name,
        description: m.description,
        price: Number(m.price),
        image: m.image,
        category: m.category,
        isAvailable: Boolean(m.isAvailable),
      })) : [] });
    }
    res.json(restaurants);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

app.post('/api/restaurants', async (req, res) => {
  try {
    const { name, cuisine, image = null, menu = [] } = req.body;
    const [result] = await db.query('INSERT INTO restaurants (name, cuisine, image) VALUES (?, ?, ?)', [name, cuisine, image]);
    const restaurantId = result.insertId;
    const insertedMenu = [];
    if (Array.isArray(menu)) {
      for (const m of menu) {
        const [mr] = await db.query('INSERT INTO menu_items (restaurantId, name, description, price, image, category, isAvailable) VALUES (?, ?, ?, ?, ?, ?, ?)', [restaurantId, m.name, m.description || null, m.price || 0, m.image || null, m.category || null, m.isAvailable ? 1 : 0]);
        insertedMenu.push({ id: mr.insertId, name: m.name, description: m.description || '', price: Number(m.price) || 0, image: m.image || '', category: m.category || '', isAvailable: Boolean(m.isAvailable) });
      }
    }
    const [rows] = await db.query('SELECT * FROM restaurants WHERE id = ?', [restaurantId]);
    const created = rows[0];
    res.status(201).json({ ...created, menu: insertedMenu });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

app.put('/api/restaurants/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { name, cuisine, image = null, menu = [] } = req.body;
    await db.query('UPDATE restaurants SET name = ?, cuisine = ?, image = ? WHERE id = ?', [name, cuisine, image, id]);

    // Fetch existing menu item ids
    const [existingRows] = await db.query('SELECT id FROM menu_items WHERE restaurantId = ?', [id]);
    const existingIds = Array.isArray(existingRows) ? existingRows.map(r => r.id) : [];

    const incomingIds = [];
    if (Array.isArray(menu)) {
      for (const m of menu) {
        if (m.id) {
          incomingIds.push(m.id);
          await db.query('UPDATE menu_items SET name = ?, description = ?, price = ?, image = ?, category = ?, isAvailable = ? WHERE id = ?', [m.name, m.description || null, m.price || 0, m.image || null, m.category || null, m.isAvailable ? 1 : 0, m.id]);
        } else {
          const [mr] = await db.query('INSERT INTO menu_items (restaurantId, name, description, price, image, category, isAvailable) VALUES (?, ?, ?, ?, ?, ?, ?)', [id, m.name, m.description || null, m.price || 0, m.image || null, m.category || null, m.isAvailable ? 1 : 0]);
          incomingIds.push(mr.insertId);
        }
      }
    }

    // Delete menu items that were removed
    const toDelete = existingIds.filter(eid => !incomingIds.includes(eid));
    if (toDelete.length > 0) {
      await db.query(`DELETE FROM menu_items WHERE id IN (${toDelete.map(() => '?').join(',')})`, toDelete);
    }

    // Return updated restaurant with menu
    const [rows] = await db.query('SELECT * FROM restaurants WHERE id = ?', [id]);
    const [menuRows] = await db.query('SELECT * FROM menu_items WHERE restaurantId = ? ORDER BY id ASC', [id]);
    const restaurant = rows[0];
    res.json({ ...restaurant, menu: Array.isArray(menuRows) ? menuRows.map(m => ({ id: m.id, name: m.name, description: m.description, price: Number(m.price), image: m.image, category: m.category, isAvailable: Boolean(m.isAvailable) })) : [] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

app.delete('/api/restaurants/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    await db.query('DELETE FROM menu_items WHERE restaurantId = ?', [id]);
    await db.query('DELETE FROM restaurants WHERE id = ?', [id]);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

// --- Messages endpoints (simple persistence)
// GET /api/messages?userId=123  -> returns messages where fromId or toId equals userId
app.get('/api/messages', async (req, res) => {
  try {
    const userId = req.query.userId ? Number(req.query.userId) : null;
    if (userId) {
      const [rows] = await db.query('SELECT * FROM messages WHERE fromId = ? OR toId = ? ORDER BY id DESC LIMIT 500', [userId, userId]);
      return res.json(rows);
    }
    const [rows] = await db.query('SELECT * FROM messages ORDER BY id DESC LIMIT 500');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

// Create a message
app.post('/api/messages', async (req, res) => {
  try {
    const { fromId, toId, orderId = null, text } = req.body;
    if (!fromId || !toId || !text) return res.status(400).json({ error: 'invalid' });
    const [result] = await db.query('INSERT INTO messages (fromId, toId, orderId, text, timestamp) VALUES (?, ?, ?, ?, NOW())', [fromId, toId, orderId, text]);
    const [rows] = await db.query('SELECT * FROM messages WHERE id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database_error' });
  }
});

app.listen(port, () => console.log(`Server listening on http://localhost:${port}`));
