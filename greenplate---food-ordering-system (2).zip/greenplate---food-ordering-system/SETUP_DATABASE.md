# GreenPlate Database Setup Guide

## Step 1: Import Database into XAMPP

1. **Start XAMPP**:
   - Open XAMPP Control Panel
   - Click "Start" for **Apache** and **MySQL**

2. **Open phpMyAdmin**:
   - Go to `http://localhost/phpmyadmin` in your browser

3. **Import the Database**:
   - Click on "Import" tab
   - Click "Choose File"
   - Navigate to: `server/migrations/full_dump.sql`
   - Click "Go" at the bottom
   
   **Alternative (SQL tab method)**:
   - Click "SQL" tab
   - Open `server/migrations/full_dump.sql` in a text editor
   - Copy ALL the contents
   - Paste into the SQL box in phpMyAdmin
   - Click "Go"

4. **Verify Database Created**:
   - You should see `greenplate` database in the left sidebar
   - Click on it
   - You should see tables: `users`, `restaurants`, `menu_items`, `orders`, `messages`

## Step 2: Start the Backend Server

Open a **NEW** PowerShell terminal in VS Code and run:

```powershell
cd server
npm install
npm start
```

You should see: `Server listening on http://localhost:3001`

**Keep this terminal running!**

## Step 3: Start the Frontend

Open **ANOTHER** PowerShell terminal and run:

```powershell
npm run dev
```

You should see: `Local: http://localhost:3000/`

## Step 4: Test Registration

1. Open browser to `http://localhost:3000`
2. Click "Don't have an account? Sign Up"
3. Fill in the registration form:
   - Name: Test User
   - Email: newuser@test.com
   - Password: test123
   - Phone: 555-1234
   - Role: Customer
4. Click "Sign Up"

## Step 5: Verify Data in Database

1. Go back to phpMyAdmin (`http://localhost/phpmyadmin`)
2. Click `greenplate` database
3. Click `users` table
4. Click "Browse" tab
5. You should see your new user in the list!

## Troubleshooting

### Registration doesn't save to database:

**Check 1: Is MySQL running?**
- Open XAMPP Control Panel
- MySQL should show "Running" in green

**Check 2: Is the backend server running?**
- Check the PowerShell terminal where you ran `npm start`
- It should say "Server listening on http://localhost:3001"
- No errors should be visible

**Check 3: Is the database imported?**
- Open phpMyAdmin
- Check if `greenplate` database exists
- Check if `users` table exists inside it

**Check 4: Check browser console**
- Press F12 in browser
- Go to "Console" tab
- Try registering again
- Look for any red error messages
- If you see "POST http://localhost:3000/api/users 500" - the server has an error
- If you see "POST http://localhost:3000/api/users 201" - success!

**Check 5: Check server terminal**
- Look at the terminal where backend is running
- After registration, you should see database queries logged
- Any errors will appear here

### Common Errors:

**Error: "ECONNREFUSED 127.0.0.1:3306"**
- MySQL is not running in XAMPP
- Start MySQL in XAMPP Control Panel

**Error: "database_error" in API response**
- Database doesn't exist or tables are missing
- Re-import `full_dump.sql` in phpMyAdmin

**Error: "email_exists"**
- Email is already registered
- Try a different email address

## Quick Test Command

Open PowerShell and run this to test if backend is working:

```powershell
Invoke-RestMethod -Uri "http://localhost:3001/api/users" -Method GET
```

This should return a list of users from the database.
