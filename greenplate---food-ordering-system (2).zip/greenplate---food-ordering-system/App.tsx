
import React, { useState, useContext, createContext, useMemo, useCallback, useEffect } from 'react';
import type { User, Restaurant, MenuItem, CartItem, Order, OrderItem } from './types';
import { UserRole, OrderStatus } from './types';
import { USERS as mockUsers, RESTAURANTS as mockRestaurants, ORDERS as mockOrders } from './constants';
import {
  IconHome, IconHistory, IconShoppingCart, IconUser, IconLogout, IconDashboard, IconRestaurant,
  IconTruck, IconList, IconArrowLeft, IconMapPin, IconClock, IconStar, IconPlus, IconMinus,
  IconChevronDown, IconSearch, IconCheckCircle, IconX, IconCalendar
} from './constants';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { GoogleGenAI } from "@google/genai";


// --- DATA CONTEXT --- //
interface DataContextType {
    users: User[];
    restaurants: Restaurant[];
    orders: Order[];
    updateOrderStatus: (orderId: number, status: OrderStatus, agentId?: number) => void;
    addOrder: (order: Omit<Order, 'id' | 'orderDate' | 'status'> & { status?: OrderStatus }) => Promise<void>;
    addUser: (user: Omit<User, 'id' | 'avatar'>) => void;
    updateUser: (userId: number, updates: Partial<User>) => void;
    removeUser: (userId: number) => void;
    addDeliveryFeedback: (orderId: number, feedback: { rating: number; comment: string; }) => void;
    addRestaurant: (restaurant: Omit<Restaurant, 'id' | 'rating' | 'deliveryTime' | 'menu'>) => void;
}
const DataContext = createContext<DataContextType | null>(null);

const DataProvider = ({ children }: { children: React.ReactNode }) => {
    const defaultData = {
        users: mockUsers,
        restaurants: mockRestaurants,
        orders: mockOrders
    };

    const [appData, setAppData] = useState(defaultData);
    const [isLoaded, setIsLoaded] = useState(false);

    useEffect(() => {
        // Load from LS only once on initial mount
        try {
            const savedData = localStorage.getItem('greenplate_data');
            if (savedData) {
                const parsedData = JSON.parse(savedData);
                 if (parsedData && parsedData.users) {
                    setAppData(parsedData);
                }
            }
        } catch (e) {
            console.error("Failed to parse data from localStorage", e);
            setAppData(defaultData);
        }
        setIsLoaded(true);
    }, []);

    useEffect(() => {
        // Save to LS whenever data changes, but only after initial load is complete
        if (isLoaded) {
            try {
                localStorage.setItem('greenplate_data', JSON.stringify(appData));
            } catch (e) {
                console.error("Failed to save app data", e);
            }
        }
    }, [appData, isLoaded]);

    const { users, restaurants, orders } = appData;

    const updateOrderStatus = useCallback((orderId: number, status: OrderStatus, agentId?: number) => {
        setAppData((prev) => ({
            ...prev,
            orders: prev.orders.map((o: Order) =>
                o.id === orderId
                    ? { ...o, status, deliveryAgentId: agentId !== undefined ? agentId : o.deliveryAgentId }
                    : o
            )
        }));
    }, []);

    const addUser = useCallback((user: Omit<User, 'id' | 'avatar'>) => {
        const newUser: User = {
            ...user,
            id: Date.now(),
            avatar: `https://i.pravatar.cc/150?u=${Date.now()}`
        };
        setAppData((prev) => ({ ...prev, users: [...prev.users, newUser]}));
    }, []);

    const updateUser = useCallback((userId: number, updates: Partial<User>) => {
        setAppData((prev) => ({ ...prev, users: prev.users.map((u: User) => u.id === userId ? { ...u, ...updates } : u)}));
    }, []);
    
    const removeUser = useCallback((userId: number) => {
        setAppData((prev) => ({ ...prev, users: prev.users.filter((u: User) => u.id !== userId)}));
    }, []);

    const addDeliveryFeedback = useCallback((orderId: number, feedback: { rating: number; comment: string; }) => {
        setAppData((prev) => ({ ...prev, orders: prev.orders.map((o: Order) => o.id === orderId ? { ...o, deliveryFeedback: feedback } : o)}));
    }, []);

    const addRestaurant = useCallback((restaurant: Omit<Restaurant, 'id' | 'rating' | 'deliveryTime' | 'menu'>) => {
        const newRestaurant: Restaurant = {
            ...restaurant,
            id: Date.now(),
            rating: Math.round((Math.random() * 1.5 + 3.5) * 10) / 10, // 3.5 to 5.0
            deliveryTime: Math.floor(Math.random() * 40) + 20, // 20 to 60
            menu: [],
        };
        setAppData((prev) => ({ ...prev, restaurants: [...prev.restaurants, newRestaurant]}));
    }, []);

    const addOrder = useCallback(async (order: Omit<Order, 'id' | 'orderDate'>) => {
        const isPreorder = !!order.isPreorder;
        const newOrder: Order = {
            ...order,
            id: Date.now(),
            orderDate: new Date().toISOString(),
            status: isPreorder ? OrderStatus.SCHEDULED : OrderStatus.PENDING,
        };
        setAppData((prev) => ({...prev, orders: [newOrder, ...prev.orders]}));

        if (!isPreorder) {
            setTimeout(async () => {
                try {
                    if (!process.env.API_KEY) {
                        throw new Error("API_KEY environment variable not set.");
                    }
                    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
                    const deliveryAgents = appData.users.filter((u: User) => u.role === UserRole.DELIVERY);
                    if (deliveryAgents.length === 0) {
                        console.warn("No delivery agents available for assignment.");
                        updateOrderStatus(newOrder.id, OrderStatus.CONFIRMED);
                        return;
                    }

                    const prompt = `From this list of delivery agents: ${JSON.stringify(deliveryAgents.map((a:User) => ({id: a.id, name: a.name})))}, choose one to assign a new food order from restaurant ID ${newOrder.restaurantId}. Return only the agent's ID as a number.`;

                    const response = await ai.models.generateContent({
                        model: 'gemini-2.5-flash',
                        contents: prompt,
                    });

                    const agentIdText = response.text.trim();
                    let assignedAgentId = parseInt(agentIdText, 10);

                    if (isNaN(assignedAgentId) || !deliveryAgents.some((a: User) => a.id === assignedAgentId)) {
                        console.error("AI returned invalid agent ID, assigning randomly.");
                        assignedAgentId = deliveryAgents[Math.floor(Math.random() * deliveryAgents.length)].id;
                    }

                    console.log(`AI assigned order #${newOrder.id} to agent #${assignedAgentId}`);
                    updateOrderStatus(newOrder.id, OrderStatus.CONFIRMED, assignedAgentId);

                } catch (error) {
                    console.error("AI assignment failed, assigning randomly.", error);
                    const deliveryAgents = appData.users.filter((u: User) => u.role === UserRole.DELIVERY);
                    if (deliveryAgents.length > 0) {
                        const assignedAgentId = deliveryAgents[Math.floor(Math.random() * deliveryAgents.length)].id;
                        updateOrderStatus(newOrder.id, OrderStatus.CONFIRMED, assignedAgentId);
                    } else {
                        updateOrderStatus(newOrder.id, OrderStatus.CONFIRMED);
                    }
                }
            }, 3000);
        }
    }, [appData.users, updateOrderStatus]);

    const value = useMemo(() => ({ users, restaurants, orders, updateOrderStatus, addOrder, addUser, updateUser, removeUser, addDeliveryFeedback, addRestaurant }), [users, restaurants, orders, updateOrderStatus, addOrder, addUser, updateUser, removeUser, addDeliveryFeedback, addRestaurant]);

    return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

const useData = () => {
    const context = useContext(DataContext);
    if (!context) throw new Error('useData must be used within a DataProvider');
    return context;
}

// --- AUTH CONTEXT & SCREENS --- //
interface AuthContextType {
  user: User | null;
  login: (email: string, pass: string, role: UserRole) => boolean;
  logout: () => void;
  register: (user: Omit<User, 'id' | 'avatar'>) => boolean;
}
const AuthContext = createContext<AuthContextType | null>(null);

const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const { users, addUser } = useData();
  const [user, setUser] = useState<User | null>(null);

  const login = useCallback((email: string, pass: string, role: UserRole): boolean => {
    const foundUser = users.find(u => u.email === email && u.password === pass && u.role === role);
    if (foundUser) {
      setUser(foundUser);
      return true;
    }
    return false;
  }, [users]);

  const logout = useCallback(() => setUser(null), []);

  const register = useCallback((newUser: Omit<User, 'id' | 'avatar'>): boolean => {
      if (users.some(u => u.email === newUser.email)) {
          return false; // Email already exists
      }
      addUser(newUser);
      return true;
  }, [users, addUser]);
  
  const value = useMemo(() => ({ user, login, logout, register }), [user, login, logout, register]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};

// --- LOGIN & REGISTER SCREENS --- //
const LoginScreen = ({ showRegister }: { showRegister: () => void }) => {
    const { login } = useAuth();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState<UserRole>(UserRole.CUSTOMER);
    const [error, setError] = useState('');

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!login(email, password, role)) {
            setError('Invalid credentials for the selected role.');
        }
    };
    
    return (
        <div className="bg-emerald-50 min-h-screen flex flex-col items-center justify-center p-4">
            <div className="w-full max-w-md">
                <div className="text-center mb-8">
                    <h1 className="text-5xl font-extrabold text-emerald-700">GreenPlate</h1>
                    <p className="text-emerald-600 mt-2">Your Food, Fast and Fresh.</p>
                </div>
                <form onSubmit={handleLogin} className="bg-white shadow-2xl rounded-2xl px-8 pt-6 pb-8 mb-4">
                    <h2 className="text-2xl font-bold text-center text-gray-700 mb-6">Login</h2>
                    {error && <p className="bg-red-100 text-red-700 p-3 rounded-lg mb-4 text-center">{error}</p>}
                    <div className="mb-4">
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">Email</label>
                        <input className="shadow-sm appearance-none border rounded-lg w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-emerald-500" id="email" type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required />
                    </div>
                    <div className="mb-4">
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">Password</label>
                        <input className="shadow-sm appearance-none border rounded-lg w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-emerald-500" id="password" type="password" placeholder="******************" value={password} onChange={e => setPassword(e.target.value)} required />
                    </div>
                    <div className="mb-6">
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="role">Login as a</label>
                        <select id="role" value={role} onChange={e => setRole(e.target.value as UserRole)} className="shadow-sm border rounded-lg w-full py-3 px-4 text-gray-700 focus:outline-none focus:ring-2 focus:ring-emerald-500">
                            <option value={UserRole.CUSTOMER}>Customer</option>
                            <option value={UserRole.DELIVERY}>Delivery Agent</option>
                            <option value={UserRole.ADMIN}>Admin</option>
                        </select>
                    </div>
                     <div className="flex items-center justify-between mb-4">
                        <button className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-6 rounded-lg focus:outline-none focus:shadow-outline w-full transition-all duration-300" type="submit">
                            Sign In
                        </button>
                    </div>
                     <div className="text-center">
                        <a href="#" onClick={(e) => { e.preventDefault(); showRegister(); }} className="inline-block align-baseline font-bold text-sm text-emerald-600 hover:text-emerald-800">
                           Don't have an account? Sign Up
                        </a>
                    </div>
                </form>
            </div>
        </div>
    );
};

const RegisterScreen = ({ showLogin }: { showLogin: () => void }) => {
    const { register } = useAuth();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState<UserRole>(UserRole.CUSTOMER);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const handleRegister = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        if(register({ name, email, password, role })) {
            setSuccess('Registration successful! Redirecting to login...');
            setTimeout(showLogin, 2000);
        } else {
            setError('Email already exists. Please try another one.');
        }
    };

    return (
        <div className="bg-emerald-50 min-h-screen flex flex-col items-center justify-center p-4">
            <div className="w-full max-w-md">
                <div className="text-center mb-8">
                    <h1 className="text-5xl font-extrabold text-emerald-700">GreenPlate</h1>
                    <p className="text-emerald-600 mt-2">Create Your Account.</p>
                </div>
                <form onSubmit={handleRegister} className="bg-white shadow-2xl rounded-2xl px-8 pt-6 pb-8 mb-4">
                    <h2 className="text-2xl font-bold text-center text-gray-700 mb-6">Register</h2>
                    {error && <p className="bg-red-100 text-red-700 p-3 rounded-lg mb-4 text-center">{error}</p>}
                    {success && <p className="bg-green-100 text-green-700 p-3 rounded-lg mb-4 text-center">{success}</p>}
                    <div className="mb-4">
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="name">Full Name</label>
                        <input className="shadow-sm appearance-none border rounded-lg w-full py-3 px-4 text-gray-700" id="name" type="text" placeholder="Full Name" value={name} onChange={e => setName(e.target.value)} required />
                    </div>
                    <div className="mb-4">
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">Email</label>
                        <input className="shadow-sm appearance-none border rounded-lg w-full py-3 px-4 text-gray-700" id="email" type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required />
                    </div>
                    <div className="mb-4">
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">Password</label>
                        <input className="shadow-sm appearance-none border rounded-lg w-full py-3 px-4 text-gray-700" id="password" type="password" placeholder="******************" value={password} onChange={e => setPassword(e.target.value)} required />
                    </div>
                    <div className="mb-6">
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="role">Register as a</label>
                        <select id="role" value={role} onChange={e => setRole(e.target.value as UserRole)} className="shadow-sm border rounded-lg w-full py-3 px-4 text-gray-700">
                            <option value={UserRole.CUSTOMER}>Customer</option>
                            <option value={UserRole.DELIVERY}>Delivery Agent</option>
                            <option value={UserRole.ADMIN}>Admin</option>
                        </select>
                    </div>
                    <div className="flex items-center justify-between mb-4">
                        <button className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-6 rounded-lg w-full" type="submit">
                            Sign Up
                        </button>
                    </div>
                     <div className="text-center">
                        <a href="#" onClick={(e) => { e.preventDefault(); showLogin(); }} className="inline-block align-baseline font-bold text-sm text-emerald-600 hover:text-emerald-800">
                           Already have an account? Login
                        </a>
                    </div>
                </form>
            </div>
        </div>
    );
}

// --- CART CONTEXT --- //
interface CartContextType { cart: CartItem[]; restaurantId: number | null; addToCart: (item: MenuItem, restaurantId: number) => void; removeFromCart: (itemId: number) => void; updateQuantity: (itemId: number, quantity: number) => void; clearCart: () => void; cartTotal: number; cartCount: number; }
const CartContext = createContext<CartContextType | null>(null);
const CartProvider = ({ children }: { children: React.ReactNode }) => {
    const [cart, setCart] = useState<CartItem[]>([]);
    const [restaurantId, setRestaurantId] = useState<number | null>(null);
    const addToCart = (item: MenuItem, restId: number) => {
        if (!item.isAvailable) return;
        if (restaurantId && restId !== restaurantId) {
            if(window.confirm("You have items from another restaurant in your cart. Would you like to clear your cart and add this item?")) {
                setCart([{...item, quantity: 1}]); setRestaurantId(restId);
            } return;
        }
        setRestaurantId(restId);
        setCart(prev => {
            const existing = prev.find(i => i.id === item.id);
            if (existing) { return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i); }
            return [...prev, { ...item, quantity: 1 }];
        });
    };
    const removeFromCart = (itemId: number) => {
        setCart(prev => {
            const newCart = prev.filter(i => i.id !== itemId);
            if (newCart.length === 0) setRestaurantId(null);
            return newCart;
        });
    };
    const updateQuantity = (itemId: number, quantity: number) => {
        if (quantity <= 0) { removeFromCart(itemId); } else { setCart(prev => prev.map(i => i.id === itemId ? { ...i, quantity } : i)); }
    };
    const clearCart = () => { setCart([]); setRestaurantId(null); }
    const cartTotal = useMemo(() => cart.reduce((sum, item) => sum + item.price * item.quantity, 0), [cart]);
    const cartCount = useMemo(() => cart.reduce((sum, item) => sum + item.quantity, 0), [cart]);
    const value = useMemo(() => ({ cart, restaurantId, addToCart, removeFromCart, updateQuantity, clearCart, cartTotal, cartCount }), [cart, restaurantId, cartTotal, cartCount]);
    return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
const useCart = () => { const context = useContext(CartContext); if (!context) throw new Error('useCart must be used within a CartProvider'); return context; }

// --- COMMON UI COMPONENTS --- //
const Header = ({ title }: { title: string }) => {
  const { user, logout } = useAuth();
  const { cartCount } = useCart();
  return (
    <header className="bg-white shadow-sm p-4 flex justify-between items-center sticky top-0 z-10">
      <h1 className="text-2xl font-bold text-gray-800">{title}</h1>
      <div className="flex items-center space-x-4">
        {user?.role === UserRole.CUSTOMER && (
            <div className="relative">
                <IconShoppingCart className="w-7 h-7 text-gray-600" />
                {cartCount > 0 && <span className="absolute -top-2 -right-2 bg-emerald-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">{cartCount}</span>}
            </div>
        )}
        <div className="text-right">
          <p className="font-semibold text-gray-700">{user?.name}</p>
          <p className="text-sm text-gray-500 capitalize">{user?.role.toLowerCase()}</p>
        </div>
        <img src={user?.avatar} alt="avatar" className="w-12 h-12 rounded-full border-2 border-emerald-200" />
      </div>
    </header>
  );
};
const Sidebar = ({ navigation, activePage, setActivePage }: { navigation: any[], activePage: string, setActivePage: (page: string) => void }) => {
  const { logout } = useAuth();
  const { user } = useAuth();
  const logoIcon = useMemo(() => {
    if (user?.role === UserRole.DELIVERY) return IconTruck;
    if (user?.role === UserRole.ADMIN) return IconDashboard;
    return IconRestaurant;
  }, [user]);
  
  return (
    <aside className="w-64 bg-emerald-800 text-white flex flex-col min-h-screen">
      <div className="p-6 text-2xl font-bold border-b border-emerald-700 flex items-center">
        {React.createElement(logoIcon, {className: "w-8 h-8 mr-2"})} GreenPlate
      </div>
      <nav className="flex-1 p-4 space-y-2">
        {navigation.map(item => (
          <a key={item.name} href="#" onClick={(e) => { e.preventDefault(); setActivePage(item.id); }}
            className={`flex items-center px-4 py-3 rounded-lg transition-colors ${activePage === item.id ? 'bg-emerald-600' : 'hover:bg-emerald-700'}`}>
            <item.icon className="w-6 h-6 mr-3" /> <span>{item.name}</span>
          </a>
        ))}
      </nav>
      <div className="p-4 border-t border-emerald-700">
        <a href="#" onClick={(e) => {e.preventDefault(); logout();}} className="flex items-center px-4 py-3 rounded-lg hover:bg-emerald-700 transition-colors">
          <IconLogout className="w-6 h-6 mr-3" /> <span>Logout</span>
        </a>
      </div>
    </aside>
  );
};
const statusColors: { [key in OrderStatus]: string } = {
  [OrderStatus.PENDING]: 'bg-yellow-100 text-yellow-800', [OrderStatus.SCHEDULED]: 'bg-cyan-100 text-cyan-800', [OrderStatus.CONFIRMED]: 'bg-blue-100 text-blue-800', [OrderStatus.PREPARING]: 'bg-indigo-100 text-indigo-800',
  [OrderStatus.OUT_FOR_DELIVERY]: 'bg-purple-100 text-purple-800', [OrderStatus.DELIVERED]: 'bg-green-100 text-green-800', [OrderStatus.CANCELLED]: 'bg-red-100 text-red-800',
};
const Card = ({ children, className, ...props }: { children: React.ReactNode, className?: string } & React.HTMLAttributes<HTMLDivElement>) => (
    <div className={`bg-white rounded-xl shadow-md overflow-hidden ${className}`} {...props}>{children}</div>
);
const Button = ({ children, onClick, className, variant = 'primary', type = 'button', disabled = false }: { children: React.ReactNode, onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void, className?: string, variant?: 'primary' | 'secondary' | 'danger', type?: 'button' | 'submit', disabled?: boolean }) => {
    const baseClasses = 'font-bold py-2 px-4 rounded-lg transition-all duration-300 focus:outline-none focus:ring-2 disabled:opacity-50 disabled:cursor-not-allowed';
    const variantClasses = {
        primary: 'bg-emerald-600 hover:bg-emerald-700 text-white focus:ring-emerald-500',
        secondary: 'bg-gray-200 hover:bg-gray-300 text-gray-800 focus:ring-gray-400',
        danger: 'bg-red-500 hover:bg-red-600 text-white focus:ring-red-400',
    };
    return ( <button onClick={onClick} type={type} disabled={disabled} className={`${baseClasses} ${variantClasses[variant]} ${className}`}>{children}</button> );
}
const OrderStatusBadge = ({ status }: { status: OrderStatus }) => ( <span className={`px-3 py-1 text-sm font-semibold rounded-full ${statusColors[status]}`}>{status}</span> );

// --- CUSTOMER DASHBOARD --- //
const RestaurantList = ({ onSelectRestaurant }: { onSelectRestaurant: (id: number) => void }) => {
    const { restaurants } = useData();
    const [searchTerm, setSearchTerm] = useState('');

    const filteredRestaurants = useMemo(() => 
        restaurants.filter(r => 
            r.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
            r.cuisine.toLowerCase().includes(searchTerm.toLowerCase())
        ), [restaurants, searchTerm]);

    return (
        <div>
            <div className="mb-6 relative">
                <input 
                    type="text" 
                    placeholder="Search restaurants or cuisine..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full p-4 pl-12 rounded-lg border focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
                <IconSearch className="w-6 h-6 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2" />
            </div>
            <h2 className="text-3xl font-bold mb-6 text-gray-800">Restaurants</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredRestaurants.map(r => (
                    <Card key={r.id} onClick={() => onSelectRestaurant(r.id)} className="hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer">
                        <img className="h-48 w-full object-cover" src={r.image} alt={r.name} />
                        <div className="p-6">
                            <h3 className="text-xl font-bold mb-2">{r.name}</h3>
                            <p className="text-gray-600 mb-4">{r.cuisine}</p>
                            <div className="flex justify-between items-center text-sm text-gray-500">
                                <span className="flex items-center"><IconStar className="w-5 h-5 text-yellow-400 mr-1" /> {r.rating}</span>
                                <span className="flex items-center"><IconClock className="w-5 h-5 text-gray-400 mr-1" /> {r.deliveryTime} min</span>
                            </div>
                        </div>
                    </Card>
                ))}
            </div>
        </div>
    );
};

const RestaurantMenu = ({ restaurant, onBack }: { restaurant: Restaurant, onBack: () => void }) => {
    const { addToCart } = useCart();
    const menuByCategory = restaurant.menu.reduce((acc, item) => {
        if (!acc[item.category]) acc[item.category] = [];
        acc[item.category].push(item);
        return acc;
    }, {} as Record<string, MenuItem[]>);

    return (
        <div>
            <button onClick={onBack} className="flex items-center text-emerald-600 font-semibold mb-6 hover:text-emerald-800">
                <IconArrowLeft className="w-5 h-5 mr-2" /> Back to Restaurants
            </button>
            <div className="flex items-center mb-8">
                <img src={restaurant.image} className="w-32 h-32 rounded-lg object-cover mr-6 shadow-lg" />
                <div>
                    <h2 className="text-4xl font-extrabold text-gray-800">{restaurant.name}</h2>
                    <p className="text-gray-600">{restaurant.cuisine}</p>
                </div>
            </div>

            {Object.entries(menuByCategory).map(([category, items]) => (
                <div key={category} className="mb-8">
                    <h3 className="text-2xl font-bold border-b-2 border-emerald-200 pb-2 mb-4">{category}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {items.map(item => (
                            <Card key={item.id} className={`flex ${!item.isAvailable ? 'opacity-50' : ''}`}>
                                <img src={item.image} alt={item.name} className="w-32 h-32 object-cover" />
                                <div className="p-4 flex flex-col justify-between flex-1">
                                    <div>
                                        <h4 className="font-bold">{item.name}</h4>
                                        <p className="text-sm text-gray-600">{item.description}</p>
                                         {!item.isAvailable && <p className="text-sm text-red-500 font-semibold mt-1">Currently unavailable</p>}
                                    </div>
                                    <div className="flex justify-between items-end mt-2">
                                        <p className="font-semibold text-lg text-emerald-700">${item.price.toFixed(2)}</p>
                                        <button onClick={() => addToCart(item, restaurant.id)} disabled={!item.isAvailable} className="bg-emerald-100 text-emerald-700 p-2 rounded-full hover:bg-emerald-200 transition-colors disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed">
                                            <IconPlus className="w-5 h-5"/>
                                        </button>
                                    </div>
                                </div>
                            </Card>
                        ))}
                    </div>
                </div>
            ))}
        </div>
    );
};

const PreorderModal = ({ onClose, onConfirm }: { onClose: () => void, onConfirm: (datetime: string) => void }) => {
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');

    const handleConfirm = () => {
        if(date && time) {
            onConfirm(`${date}T${time}`);
        } else {
            alert("Please select a date and time.");
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
                <div className="flex justify-between items-center border-b pb-3 mb-4">
                    <h2 className="text-xl font-bold">Schedule Your Order</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800"><IconX className="w-6 h-6" /></button>
                </div>
                <div className="space-y-4">
                    <div>
                        <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                        <input type="date" id="date" value={date} onChange={e => setDate(e.target.value)} className="w-full p-2 border rounded-md" min={new Date().toISOString().split('T')[0]}/>
                    </div>
                    <div>
                        <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-1">Time</label>
                        <input type="time" id="time" value={time} onChange={e => setTime(e.target.value)} className="w-full p-2 border rounded-md" />
                    </div>
                </div>
                <div className="mt-6 flex justify-end space-x-2">
                    <Button onClick={onClose} variant="secondary">Cancel</Button>
                    <Button onClick={handleConfirm} disabled={!date || !time}>Confirm Preorder</Button>
                </div>
            </div>
        </div>
    );
}

const CartView = () => {
    const { cart, restaurantId, updateQuantity, clearCart, cartTotal } = useCart();
    const { restaurants, addOrder } = useData();
    const { user } = useAuth();
    const [isPreordering, setIsPreordering] = useState(false);
    
    if (cart.length === 0) {
        return <div className="p-6 bg-gray-50 rounded-lg text-center"><p className="text-gray-500">Your cart is empty.</p></div>
    }

    const placeOrder = (preorderDate?: string) => {
        if (!user || !restaurantId) return;
        const order: Omit<Order, 'id' | 'orderDate' | 'status'> = {
            customerId: user.id, restaurantId: restaurantId,
            items: cart.map(item => ({ menuItemId: item.id, name: item.name, quantity: item.quantity, price: item.price })),
            total: cartTotal, deliveryAddress: '123 Green St, Cityville', isPreorder: !!preorderDate,
            scheduledDelivery: preorderDate,
        };
        addOrder(order);
        alert(`Order placed successfully! ${preorderDate ? 'Your preorder is scheduled.' : 'It will be delivered shortly.'}`);
        clearCart();
        setIsPreordering(false);
    }
    
    const restaurantName = restaurants.find(r => r.id === restaurantId)?.name || '...';

    return (
        <div className="p-6 bg-white shadow-lg rounded-lg">
            <h3 className="text-2xl font-bold mb-4">Your Order from <span className="text-emerald-600">{restaurantName}</span></h3>
            {cart.map(item => (
                <div key={item.id} className="flex items-center justify-between py-3 border-b">
                    <div><p className="font-semibold">{item.name}</p><p className="text-sm text-gray-600">${item.price.toFixed(2)}</p></div>
                    <div className="flex items-center space-x-3">
                         <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="bg-gray-200 p-1 rounded-full"><IconMinus className="w-4 h-4" /></button>
                         <span>{item.quantity}</span>
                         <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="bg-gray-200 p-1 rounded-full"><IconPlus className="w-4 h-4" /></button>
                    </div>
                    <p className="font-bold">${(item.price * item.quantity).toFixed(2)}</p>
                </div>
            ))}
            <div className="mt-6 flex justify-between items-center font-bold text-xl">
                <span>Total:</span><span>${cartTotal.toFixed(2)}</span>
            </div>
            <div className="mt-6 space-y-2">
                <Button onClick={() => placeOrder()} className="w-full">Checkout</Button>
                <Button onClick={() => setIsPreordering(true)} variant="secondary" className="w-full flex items-center justify-center"><IconCalendar className="w-5 h-5 mr-2"/>Preorder</Button>
                <Button onClick={clearCart} variant="danger" className="w-full">Clear Cart</Button>
            </div>
            {isPreordering && <PreorderModal onClose={() => setIsPreordering(false)} onConfirm={(datetime) => placeOrder(datetime)} />}
        </div>
    );
};

const OrderTrackingView = ({ order, onClose, restaurantName }: { order: Order, onClose: () => void, restaurantName: string }) => {
    const { restaurants } = useData();
    const trackingSteps = [
        { status: OrderStatus.CONFIRMED, title: 'Order Confirmed', icon: IconCheckCircle },
        { status: OrderStatus.PREPARING, title: 'Preparing Order', icon: IconRestaurant },
        { status: OrderStatus.OUT_FOR_DELIVERY, title: 'On The Way', icon: IconTruck },
        { status: OrderStatus.DELIVERED, title: 'Delivered', icon: IconHome },
    ];

    const getStatusTime = (status: OrderStatus) => {
        if(order.status === status) return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        // Mocking past times for completed steps
        const orderDate = new Date(order.orderDate);
        if(status === OrderStatus.CONFIRMED) return new Date(orderDate.getTime() + 2 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        if(status === OrderStatus.PREPARING) return new Date(orderDate.getTime() + 5 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        return '...';
    }
    
    const currentStatusIndex = trackingSteps.findIndex(step => step.status === order.status);
    const orderRestaurant = restaurants.find(r => r.id === order.restaurantId);
    const firstItemImage = orderRestaurant?.menu.find(m => m.id === order.items[0]?.menuItemId)?.image || orderRestaurant?.image;


    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                <div className="flex justify-between items-center border-b pb-3 mb-4">
                    <div>
                        <h2 className="text-2xl font-bold">Order #{order.id}</h2>
                        <p className="text-gray-500">{restaurantName}</p>
                    </div>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800"><IconX className="w-6 h-6"/></button>
                </div>
                
                <div className="mb-4">
                    <img src={firstItemImage} alt="food" className="w-full h-40 object-cover rounded-lg" />
                </div>
                
                <div>
                    {trackingSteps.map((step, index) => {
                        const isActive = index === currentStatusIndex;
                        const isCompleted = index < currentStatusIndex || order.status === OrderStatus.DELIVERED;
                        return (
                            <div key={step.status} className="flex items-start mb-4">
                                <div className="flex flex-col items-center mr-4">
                                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isCompleted || isActive ? 'bg-emerald-500 text-white' : 'bg-gray-200 text-gray-500'}`}>
                                        <step.icon className="w-6 h-6" />
                                    </div>
                                    {index < trackingSteps.length - 1 && <div className={`w-0.5 h-12 mt-1 ${isCompleted ? 'bg-emerald-500' : 'bg-gray-200'}`}></div>}
                                </div>
                                <div className={`pt-1.5 ${isActive ? 'text-black' : 'text-gray-500'}`}>
                                    <p className={`font-bold ${isActive ? 'text-emerald-600' : ''}`}>{step.title}</p>
                                    {(isCompleted || isActive) && <p className="text-sm">{isCompleted || order.status !== OrderStatus.PENDING ? getStatusTime(step.status) : ''}</p>}
                                </div>
                            </div>
                        )
                    })}
                </div>

                <div className="mt-6 text-right">
                    <Button onClick={onClose} variant="secondary">Close</Button>
                </div>
            </div>
        </div>
    );
};

const StarRating = ({ rating, setRating }: { rating: number, setRating?: (r: number) => void }) => (
    <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map(star => (
            <button key={star} type="button" onClick={() => setRating && setRating(star)} className={`focus:outline-none ${setRating ? '' : 'cursor-default'}`}>
                <IconStar className={`w-8 h-8 ${star <= rating ? 'text-yellow-400' : 'text-gray-300'}`} />
            </button>
        ))}
    </div>
);

const FeedbackModal = ({ order, onClose, onSave }: { order: Order, onClose: () => void, onSave: (orderId: number, feedback: {rating: number, comment: string}) => void }) => {
    const [rating, setRating] = useState(0);
    const [comment, setComment] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (rating > 0) {
            onSave(order.id, { rating, comment });
            onClose();
        } else {
            alert('Please provide a rating.');
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                <h2 className="text-xl font-bold mb-4">Leave Feedback for Order #{order.id}</h2>
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium mb-2">Rating</label>
                        <StarRating rating={rating} setRating={setRating} />
                    </div>
                    <div>
                        <label htmlFor="comment" className="block text-sm font-medium mb-1">Comment (optional)</label>
                        <textarea id="comment" value={comment} onChange={e => setComment(e.target.value)} rows={4} className="w-full p-2 border rounded-md" />
                    </div>
                </div>
                <div className="mt-6 flex justify-end space-x-2">
                    <Button onClick={onClose} variant="secondary" type="button">Cancel</Button>
                    <Button type="submit" disabled={rating === 0}>Submit Feedback</Button>
                </div>
            </form>
        </div>
    );
};

const OrderHistory = () => {
    const { user } = useAuth();
    const { orders, restaurants, addDeliveryFeedback } = useData();
    const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
    const [feedbackOrder, setFeedbackOrder] = useState<Order | null>(null);
    const customerOrders = useMemo(() => orders.filter(o => o.customerId === user?.id).sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime()), [orders, user]);
    const getRestaurantName = (id: number) => restaurants.find(r => r.id === id)?.name || 'Unknown Restaurant';

    return (
        <div>
            <h2 className="text-3xl font-bold mb-6 text-gray-800">Your Orders</h2>
            <div className="space-y-4">
                {customerOrders.length > 0 ? customerOrders.map(order => (
                    <Card key={order.id} className="p-4">
                        <div className="cursor-pointer" onClick={() => setSelectedOrder(order)}>
                            <div className="flex justify-between items-start">
                                <div>
                                    <p className="font-bold text-lg">Order #{order.id}</p>
                                    <p className="font-semibold text-gray-700">From {getRestaurantName(order.restaurantId)}</p>
                                    <p className="text-sm text-gray-500">{new Date(order.orderDate).toLocaleString()}</p>
                                    {order.isPreorder && <p className="text-sm text-blue-500 font-semibold">Preorder for: {new Date(order.scheduledDelivery!).toLocaleString()}</p>}
                                </div>
                                <div className="text-right flex-shrink-0 ml-4">
                                    <OrderStatusBadge status={order.status} />
                                    <p className="font-bold text-xl mt-1">${order.total.toFixed(2)}</p>
                                </div>
                            </div>
                            <div className="mt-3 pt-3 border-t">
                                <h4 className="font-semibold text-sm text-gray-800 mb-1">Items:</h4>
                                <ul className="space-y-1 text-sm text-gray-600">
                                    {order.items.map(item => (
                                        <li key={item.menuItemId} className="flex justify-between">
                                            <span>{item.quantity} x {item.name}</span>
                                            <span>${(item.quantity * item.price).toFixed(2)}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                        {order.status === OrderStatus.DELIVERED && (
                            <div className="mt-3 pt-3 border-t text-right">
                                {order.deliveryFeedback ? (
                                    <div className="flex items-center justify-end text-sm text-gray-600">
                                        <span>Your Rating:</span>
                                        <div className="flex ml-2">{[...Array(order.deliveryFeedback.rating)].map((_, i) => <IconStar key={i} className="w-5 h-5 text-yellow-400" />)}</div>
                                    </div>
                                ) : (
                                    <Button onClick={() => setFeedbackOrder(order)} variant="secondary" className="text-sm py-1 px-3">Leave Feedback</Button>
                                )}
                            </div>
                        )}
                    </Card>
                )) : (
                    <Card className="p-6 text-center text-gray-500">You haven't placed any orders yet.</Card>
                )}
            </div>
            {selectedOrder && <OrderTrackingView order={selectedOrder} onClose={() => setSelectedOrder(null)} restaurantName={getRestaurantName(selectedOrder.restaurantId)} />}
            {feedbackOrder && <FeedbackModal order={feedbackOrder} onClose={() => setFeedbackOrder(null)} onSave={addDeliveryFeedback} />}
        </div>
    );
};


const CustomerDashboard = () => {
    const [activePage, setActivePage] = useState('home');
    const { restaurants } = useData();
    const [selectedRestaurantId, setSelectedRestaurantId] = useState<number | null>(null);
    const handleSelectRestaurant = (id: number) => { setSelectedRestaurantId(id); setActivePage('menu'); }
    const handleBackToRestaurants = () => { setSelectedRestaurantId(null); setActivePage('home'); }
    const navigation = [ { name: 'Restaurants', id: 'home', icon: IconHome }, { name: 'Order History', id: 'history', icon: IconHistory }, { name: 'Profile', id: 'profile', icon: IconUser }, ];
    
    let pageContent;
    switch(activePage) {
        case 'home': pageContent = <RestaurantList onSelectRestaurant={handleSelectRestaurant} />; break;
        case 'menu': const restaurant = restaurants.find(r => r.id === selectedRestaurantId); pageContent = restaurant ? <RestaurantMenu restaurant={restaurant} onBack={handleBackToRestaurants} /> : <p>Restaurant not found.</p>; break;
        case 'history': pageContent = <OrderHistory />; break;
        case 'profile': pageContent = <h2>Profile Page (coming soon)</h2>; break;
        default: pageContent = <RestaurantList onSelectRestaurant={handleSelectRestaurant} />;
    }
    
    return (
        <div className="flex">
            <Sidebar navigation={navigation} activePage={activePage} setActivePage={setActivePage} />
            <main className="flex-1 bg-gray-100">
                <Header title={navigation.find(n => n.id === activePage)?.name || 'Restaurants'} />
                <div className="p-8 grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                    <div className="lg:col-span-2">{pageContent}</div>
                    <div className="lg:col-span-1 sticky top-24"><CartView /></div>
                </div>
            </main>
        </div>
    );
};

// --- DELIVERY DASHBOARD --- //
const DeliveryDashboard = () => {
    const { user } = useAuth();
    const { orders, restaurants, updateOrderStatus, updateUser } = useData();
    const [activeTab, setActiveTab] = useState<'available' | 'ongoing' | 'completed'>('available');
    const [locationStatus, setLocationStatus] = useState('');

    const availableOrders = orders.filter(o => o.status === OrderStatus.CONFIRMED);
    const ongoingOrders = orders.filter(o => o.deliveryAgentId === user?.id && o.status === OrderStatus.OUT_FOR_DELIVERY);
    const completedOrders = orders.filter(o => o.deliveryAgentId === user?.id && o.status === OrderStatus.DELIVERED);

    const handleUpdateStatus = (orderId: number, newStatus: OrderStatus) => { updateOrderStatus(orderId, newStatus, user?.id); };

    const handleUpdateLocation = () => {
        if(!navigator.geolocation) {
            setLocationStatus('Geolocation is not supported by your browser.');
            return;
        }
        setLocationStatus('Fetching location...');
        navigator.geolocation.getCurrentPosition((position) => {
            const { latitude, longitude } = position.coords;
            updateUser(user!.id, { location: { latitude, longitude, timestamp: position.timestamp } });
            setLocationStatus(`Location updated at ${new Date(position.timestamp).toLocaleTimeString()}`);
        }, () => {
            setLocationStatus('Unable to retrieve your location.');
        });
    }

    const OrderCard = ({ order }: { order: Order}) => {
        const restaurant = restaurants.find(r => r.id === order.restaurantId);
        return (
            <Card className="p-4 mb-4">
                <div className="flex justify-between items-start">
                    <div>
                        <h3 className="font-bold">Order #{order.id}</h3>
                        <p className="text-sm text-gray-600">From: {restaurant?.name}</p>
                        <p className="text-sm text-gray-600 flex items-center mt-1"><IconMapPin className="w-4 h-4 mr-1"/> {order.deliveryAddress}</p>
                    </div>
                    <div className="text-right"><p className="font-bold">${order.total.toFixed(2)}</p><OrderStatusBadge status={order.status} /></div>
                </div>
                <div className="mt-4 pt-3 border-t flex justify-end space-x-2">
                    {order.status === OrderStatus.CONFIRMED ? (<Button onClick={() => handleUpdateStatus(order.id, OrderStatus.OUT_FOR_DELIVERY)}>Pick Up</Button>)
                    : order.status === OrderStatus.OUT_FOR_DELIVERY ? (<Button onClick={() => handleUpdateStatus(order.id, OrderStatus.DELIVERED)}>Mark as Delivered</Button>) : null}
                </div>
            </Card>
        )
    };
    
    return (
        <div className="flex">
            <Sidebar navigation={[{name: 'Dashboard', id: 'dashboard', icon: IconDashboard}]} activePage="dashboard" setActivePage={() => {}} />
            <main className="flex-1 bg-gray-100">
                <Header title="Delivery Dashboard" />
                <div className="p-8">
                    <div className="mb-6 bg-white p-4 rounded-lg shadow-md flex justify-between items-center">
                        <p className="text-gray-700">{locationStatus || "Update your location for admins to see."}</p>
                        <Button onClick={handleUpdateLocation} variant="secondary">Update My Location</Button>
                    </div>
                    <div className="mb-6 border-b border-gray-200">
                        <nav className="flex space-x-8">
                            <button onClick={() => setActiveTab('available')} className={`py-4 px-1 border-b-2 font-medium ${activeTab === 'available' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>Available Orders</button>
                            <button onClick={() => setActiveTab('ongoing')} className={`py-4 px-1 border-b-2 font-medium ${activeTab === 'ongoing' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>My Deliveries</button>
                            <button onClick={() => setActiveTab('completed')} className={`py-4 px-1 border-b-2 font-medium ${activeTab === 'completed' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>Completed</button>
                        </nav>
                    </div>
                    <div>
                        {activeTab === 'available' && (availableOrders.length > 0 ? availableOrders.map(o => <OrderCard key={o.id} order={o} />) : <p>No available orders.</p>)}
                        {activeTab === 'ongoing' && (ongoingOrders.length > 0 ? ongoingOrders.map(o => <OrderCard key={o.id} order={o} />) : <p>No ongoing deliveries.</p>)}
                        {activeTab === 'completed' && (completedOrders.length > 0 ? completedOrders.map(o => <OrderCard key={o.id} order={o} />) : <p>No completed deliveries.</p>)}
                    </div>
                </div>
            </main>
        </div>
    );
};

// --- ADMIN DASHBOARD --- //
const DashboardCard = ({ title, value, icon }: { title: string, value: string, icon: React.ElementType }) => (
    <Card className="p-6 flex items-center">
        <div className="p-3 bg-emerald-100 rounded-full mr-4">{React.createElement(icon, {className: "w-8 h-8 text-emerald-600"})}</div>
        <div><p className="text-gray-500 text-sm font-medium">{title}</p><p className="text-3xl font-bold text-gray-800">{value}</p></div>
    </Card>
);
const SalesChart = ({ orders }: { orders: Order[] }) => {
    const salesData = orders.filter(o => o.status === OrderStatus.DELIVERED).reduce((acc, order) => {
        const date = new Date(order.orderDate).toLocaleDateString();
        if(!acc[date]) acc[date] = 0; acc[date] += order.total; return acc;
    }, {} as Record<string, number>);
    const chartData = Object.entries(salesData).map(([date, sales]) => ({ date, sales })).sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    return (
        <Card className="p-6">
            <h3 className="font-bold text-lg mb-4">Sales Overview</h3>
            <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" /><YAxis /><Tooltip /><Legend /><Line type="monotone" dataKey="sales" stroke="#10b981" strokeWidth={2} /></LineChart>
            </ResponsiveContainer>
        </Card>
    )
}
const RecentOrders = ({ orders, restaurants }: { orders: Order[], restaurants: Restaurant[] }) => (
    <Card className="p-6">
        <h3 className="font-bold text-lg mb-4">Recent Orders</h3>
        <div className="space-y-3">
            {orders.slice(0, 5).map(order => (<div key={order.id} className="flex justify-between items-center text-sm"><div><p className="font-semibold">#{order.id}</p><p className="text-gray-500">{restaurants.find(r => r.id === order.restaurantId)?.name}</p></div><OrderStatusBadge status={order.status} /></div>))}
        </div>
    </Card>
);

const AddAgentModal = ({ onClose, onAdd }: { onClose: () => void, onAdd: (user: Omit<User, 'id' | 'avatar' | 'role'>) => void }) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleAdd = (e: React.FormEvent) => {
        e.preventDefault();
        onAdd({ name, email, password });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <form onSubmit={handleAdd} className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
                <h2 className="text-xl font-bold mb-4">Add Delivery Agent</h2>
                <div className="space-y-4">
                     <div><label className="block text-sm font-medium">Name</label><input type="text" value={name} onChange={e => setName(e.target.value)} required className="w-full p-2 border rounded-md"/></div>
                     <div><label className="block text-sm font-medium">Email</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full p-2 border rounded-md"/></div>
                     <div><label className="block text-sm font-medium">Password</label><input type="password" value={password} onChange={e => setPassword(e.target.value)} required className="w-full p-2 border rounded-md"/></div>
                </div>
                <div className="mt-6 flex justify-end space-x-2">
                    <Button onClick={onClose} variant="secondary" type="button">Cancel</Button>
                    <Button type="submit">Add Agent</Button>
                </div>
            </form>
        </div>
    );
};

const EditUserModal = ({ user, onClose, onSave }: { user: User, onClose: () => void, onSave: (userId: number, updates: Partial<User>) => void }) => {
    const [name, setName] = useState(user.name);
    const [email, setEmail] = useState(user.email);

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(user.id, { name, email });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <form onSubmit={handleSave} className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
                <h2 className="text-xl font-bold mb-4">Edit User</h2>
                <div className="space-y-4">
                    <div><label className="block text-sm font-medium">Name</label><input type="text" value={name} onChange={e => setName(e.target.value)} required className="w-full p-2 border rounded-md"/></div>
                    <div><label className="block text-sm font-medium">Email</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full p-2 border rounded-md"/></div>
                    <div><label className="block text-sm font-medium text-gray-500">Role</label><input type="text" value={user.role} disabled className="w-full p-2 border rounded-md bg-gray-100"/></div>
                </div>
                <div className="mt-6 flex justify-end space-x-2">
                    <Button onClick={onClose} variant="secondary" type="button">Cancel</Button>
                    <Button type="submit">Save Changes</Button>
                </div>
            </form>
        </div>
    );
};

const ConfirmDeleteModal = ({ user, onClose, onConfirm }: { user: User, onClose: () => void, onConfirm: (userId: number) => void }) => {
    return (
         <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm text-center">
                <h2 className="text-xl font-bold mb-4">Confirm Deletion</h2>
                <p>Are you sure you want to delete the user <span className="font-semibold">{user.name}</span>?</p>
                <div className="mt-6 flex justify-center space-x-4">
                    <Button onClick={onClose} variant="secondary">Cancel</Button>
                    <Button onClick={() => { onConfirm(user.id); onClose(); }} variant="danger">Delete</Button>
                </div>
            </div>
        </div>
    );
};

const UserManagement = () => {
    const { users, orders, addUser, updateUser, removeUser } = useData();
    const [showAddModal, setShowAddModal] = useState(false);
    const [activeTab, setActiveTab] = useState<UserRole>(UserRole.CUSTOMER);
    const [editingUser, setEditingUser] = useState<User | null>(null);
    const [deletingUser, setDeletingUser] = useState<User | null>(null);

    const handleAddAgent = (agent: Omit<User, 'id'|'avatar'|'role'>) => {
        addUser({ ...agent, role: UserRole.DELIVERY });
    };

    const calculateAgentRating = useCallback((agentId: number) => {
        const agentOrdersWithFeedback = orders.filter(o => o.deliveryAgentId === agentId && o.deliveryFeedback);
        if (agentOrdersWithFeedback.length === 0) return 'N/A';
        const totalRating = agentOrdersWithFeedback.reduce((sum, o) => sum + o.deliveryFeedback!.rating, 0);
        return (totalRating / agentOrdersWithFeedback.length).toFixed(1) + ' ★';
    }, [orders]);

    const filteredUsers = useMemo(() => users.filter(u => u.role === activeTab), [users, activeTab]);

    const tabs = [
        { role: UserRole.CUSTOMER, name: 'Customers' },
        { role: UserRole.DELIVERY, name: 'Delivery Agents' },
        { role: UserRole.ADMIN, name: 'Admins' },
    ];

    return (
        <Card className="p-6">
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-lg">Users</h3>
                <Button onClick={() => setShowAddModal(true)}>Add Delivery Agent</Button>
            </div>
            <div className="border-b mb-4">
                <nav className="flex space-x-4 -mb-px">
                    {tabs.map(tab => (
                        <button key={tab.role} onClick={() => setActiveTab(tab.role)} 
                            className={`py-3 px-1 border-b-2 font-medium text-sm ${activeTab === tab.role ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                            {tab.name}
                        </button>
                    ))}
                </nav>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead>
                        <tr className="border-b">
                            <th className="p-3">Name</th>
                            <th className="p-3">Email</th>
                            {activeTab === UserRole.DELIVERY && <th className="p-3">Avg. Rating</th>}
                            {activeTab === UserRole.DELIVERY && <th className="p-3">Location</th>}
                            {activeTab !== UserRole.ADMIN && <th className="p-3">Actions</th>}
                        </tr>
                    </thead>
                    <tbody>
                        {filteredUsers.map(u => (
                            <tr key={u.id} className="border-b hover:bg-gray-50">
                                <td className="p-3 flex items-center"><img src={u.avatar} alt={u.name} className="w-9 h-9 rounded-full mr-3" /> {u.name}</td>
                                <td className="p-3">{u.email}</td>
                                {activeTab === UserRole.DELIVERY && <td className="p-3">{calculateAgentRating(u.id)}</td>}
                                {activeTab === UserRole.DELIVERY && <td className="p-3">{u.location ? <a href={`https://www.google.com/maps?q=${u.location.latitude},${u.location.longitude}`} target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:underline">View Map</a> : 'N/A'}</td>}
                                {activeTab !== UserRole.ADMIN && (
                                    <td className="p-3 space-x-2">
                                        <Button onClick={() => setEditingUser(u)} variant="secondary" className="py-1 px-3 text-sm">Edit</Button>
                                        <Button onClick={() => setDeletingUser(u)} variant="danger" className="py-1 px-3 text-sm">Remove</Button>
                                    </td>
                                )}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {showAddModal && <AddAgentModal onClose={() => setShowAddModal(false)} onAdd={handleAddAgent} />}
            {editingUser && <EditUserModal user={editingUser} onClose={() => setEditingUser(null)} onSave={updateUser} />}
            {deletingUser && <ConfirmDeleteModal user={deletingUser} onClose={() => setDeletingUser(null)} onConfirm={removeUser} />}
        </Card>
    );
}

const AddRestaurantModal = ({ onClose, onAdd }: { onClose: () => void, onAdd: (restaurant: Omit<Restaurant, 'id' | 'rating' | 'deliveryTime' | 'menu'>) => void }) => {
    const [name, setName] = useState('');
    const [cuisine, setCuisine] = useState('');
    const [image, setImage] = useState('');

    const handleAdd = (e: React.FormEvent) => {
        e.preventDefault();
        onAdd({ name, cuisine, image });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <form onSubmit={handleAdd} className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
                <h2 className="text-xl font-bold mb-4">Add Restaurant</h2>
                <div className="space-y-4">
                     <div><label className="block text-sm font-medium">Name</label><input type="text" value={name} onChange={e => setName(e.target.value)} required className="w-full p-2 border rounded-md"/></div>
                     <div><label className="block text-sm font-medium">Cuisine</label><input type="text" value={cuisine} onChange={e => setCuisine(e.target.value)} required className="w-full p-2 border rounded-md"/></div>
                     <div><label className="block text-sm font-medium">Image URL</label><input type="url" value={image} onChange={e => setImage(e.target.value)} required className="w-full p-2 border rounded-md"/></div>
                </div>
                <div className="mt-6 flex justify-end space-x-2">
                    <Button onClick={onClose} variant="secondary" type="button">Cancel</Button>
                    <Button type="submit">Add Restaurant</Button>
                </div>
            </form>
        </div>
    );
};

const RestaurantManagement = () => {
    const { restaurants, addRestaurant } = useData();
    const [showAddModal, setShowAddModal] = useState(false);
    return(
        <Card className="p-6">
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-lg">Restaurants</h3>
                <Button onClick={() => setShowAddModal(true)}>Add Restaurant</Button>
            </div>
            <table className="w-full text-left">
                <thead><tr className="border-b"><th className="py-2">Name</th><th>Cuisine</th><th>Rating</th></tr></thead>
                <tbody>{restaurants.map(r => (<tr key={r.id} className="border-b"><td className="py-2">{r.name}</td><td>{r.cuisine}</td><td>{r.rating}</td></tr>))}</tbody>
            </table>
            {showAddModal && <AddRestaurantModal onClose={() => setShowAddModal(false)} onAdd={addRestaurant} />}
        </Card>
    );
};

const OrderManagement = () => {
    const { orders, updateOrderStatus, users } = useData();

    const getCustomerName = (customerId: number) => {
        return users.find(u => u.id === customerId)?.name || 'Unknown';
    }

    return (
        <Card className="p-6">
            <h3 className="font-bold text-lg mb-4">Manage Orders</h3>
            <div className="space-y-4">
                {orders.map(order => (
                    <div key={order.id} className="p-3 border rounded-lg">
                        <div className="flex justify-between items-start">
                            <div>
                                <p className="font-bold">Order #{order.id}</p>
                                <p className="text-sm text-gray-600">Customer: {getCustomerName(order.customerId)}</p>
                                <p className="text-sm text-gray-600">Total: ${order.total.toFixed(2)}</p>
                            </div>
                            <div className="flex items-center space-x-2">
                                <OrderStatusBadge status={order.status} />
                                <select 
                                    value={order.status} 
                                    onChange={(e) => updateOrderStatus(order.id, e.target.value as OrderStatus)} 
                                    className="p-1 border rounded text-sm focus:ring-emerald-500 focus:border-emerald-500"
                                >
                                    {Object.values(OrderStatus).map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                            </div>
                        </div>
                        <div className="mt-2 pt-2 border-t">
                             <h4 className="font-semibold text-sm">Items:</h4>
                             <ul className="list-disc pl-5 text-sm text-gray-700">
                                {order.items.map(item => (
                                    <li key={item.menuItemId}>{item.quantity} x {item.name}</li>
                                ))}
                            </ul>
                        </div>
                    </div>
                ))}
            </div>
        </Card>
    );
};

const AdminDashboard = () => {
    const { users, restaurants, orders } = useData();
    const [activePage, setActivePage] = useState('dashboard');
    const navigation = [ { name: 'Dashboard', id: 'dashboard', icon: IconDashboard }, { name: 'Orders', id: 'orders', icon: IconList }, { name: 'Users', id: 'users', icon: IconUser }, { name: 'Restaurants', id: 'restaurants', icon: IconRestaurant }, ];
    const totalRevenue = orders.reduce((sum, o) => o.status === 'Delivered' ? sum + o.total : sum, 0);
    const totalOrders = orders.length;
    
    let pageContent;
    switch(activePage) {
        case 'dashboard': pageContent = (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <DashboardCard title="Total Revenue" value={`$${totalRevenue.toFixed(2)}`} icon={IconShoppingCart} />
                    <DashboardCard title="Total Orders" value={totalOrders.toString()} icon={IconList} />
                    <DashboardCard title="Customers" value={users.filter(u=>u.role===UserRole.CUSTOMER).length.toString()} icon={IconUser} />
                    <DashboardCard title="Delivery Agents" value={users.filter(u=>u.role===UserRole.DELIVERY).length.toString()} icon={IconTruck} />
                    <DashboardCard title="Restaurants" value={restaurants.length.toString()} icon={IconRestaurant} />
                    <div className="lg:col-span-4"><SalesChart orders={orders} /></div>
                    <div className="lg:col-span-4"><RecentOrders orders={orders} restaurants={restaurants} /></div>
                </div>
            ); break;
        case 'orders': pageContent = <OrderManagement />; break;
        case 'users': pageContent = <UserManagement />; break;
        case 'restaurants': pageContent = <RestaurantManagement />; break;
        default: pageContent = <h2>Dashboard</h2>;
    }

    return (
        <div className="flex"><Sidebar navigation={navigation} activePage={activePage} setActivePage={setActivePage} />
            <main className="flex-1 bg-gray-100"><Header title={navigation.find(n => n.id === activePage)?.name || 'Dashboard'} /><div className="p-8">{pageContent}</div></main>
        </div>
    );
};


// --- MAIN APP --- //
export default function App() {
  return ( <DataProvider><AuthProvider><AppContent /></AuthProvider></DataProvider> );
}

const AppContent = () => {
    const { user } = useAuth();
    const [view, setView] = useState<'login' | 'register'>('login');
    
    if (!user) {
        if(view === 'login') return <LoginScreen showRegister={() => setView('register')} />;
        if(view === 'register') return <RegisterScreen showLogin={() => setView('login')} />;
    }
    
    return (
        <CartProvider>
            {user.role === UserRole.CUSTOMER && <CustomerDashboard />}
            {user.role === UserRole.DELIVERY && <DeliveryDashboard />}
            {user.role === UserRole.ADMIN && <AdminDashboard />}
        </CartProvider>
    );
}
