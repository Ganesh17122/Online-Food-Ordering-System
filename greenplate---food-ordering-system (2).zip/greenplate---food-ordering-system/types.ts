export enum UserRole {
  CUSTOMER = 'CUSTOMER',
  DELIVERY = 'DELIVERY',
  ADMIN = 'ADMIN',
}

export enum OrderStatus {
  PENDING = 'Pending',
  SCHEDULED = 'Scheduled',
  CONFIRMED = 'Confirmed',
  PREPARING = 'Preparing',
  OUT_FOR_DELIVERY = 'Out for Delivery',
  DELIVERED = 'Delivered',
  CANCELLED = 'Cancelled',
}

export interface User {
  id: number;
  name: string;
  email: string;
  password?: string; // Should not be sent to frontend in real app
  role: UserRole;
  avatar: string;
  location?: {
    latitude: number;
    longitude: number;
    timestamp: number;
  };
}

export interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isAvailable: boolean;
}

export interface Restaurant {
  id: number;
  name: string;
  cuisine: string;
  rating: number;
  deliveryTime: number; // in minutes
  image: string;
  menu: MenuItem[];
}

export interface CartItem extends MenuItem {
  quantity: number;
}

export interface OrderItem {
  menuItemId: number;
  name: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: number;
  customerId: number;
  restaurantId: number;
  deliveryAgentId?: number;
  items: OrderItem[];
  total: number;
  status: OrderStatus;
  orderDate: string;
  deliveryAddress: string;
  isPreorder: boolean;
  scheduledDelivery?: string;
  deliveryFeedback?: {
    rating: number;
    comment: string;
  };
}