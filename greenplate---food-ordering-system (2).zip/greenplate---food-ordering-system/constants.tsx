
import React from 'react';
import type { User, Restaurant, Order } from './types';
import { UserRole, OrderStatus } from './types';

// Mock Data
export const USERS: User[] = [
  { id: 1, name: 'Alice Johnson', email: 'customer@example.com', password: 'password', role: UserRole.CUSTOMER, avatar: 'https://i.pravatar.cc/150?u=customer@example.com' },
  { id: 2, name: 'Bob Williams', email: 'delivery@example.com', password: 'password', role: UserRole.DELIVERY, avatar: 'https://i.pravatar.cc/150?u=delivery@example.com' },
  { id: 3, name: 'Charlie Brown', email: 'admin@example.com', password: 'password', role: UserRole.ADMIN, avatar: 'https://i.pravatar.cc/150?u=admin@example.com' },
  { id: 4, name: 'David Smith', email: 'delivery2@example.com', password: 'password', role: UserRole.DELIVERY, avatar: 'https://i.pravatar.cc/150?u=delivery2@example.com' },

];

export const RESTAURANTS: Restaurant[] = [
  {
    id: 1, name: 'The Green Leaf', cuisine: 'Italian', rating: 4.8, deliveryTime: 25, image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=2070&auto=format&fit=crop',
    menu: [
      { id: 101, name: 'Margherita Pizza', description: 'Classic cheese and tomato pizza.', price: 12.99, image: 'https://images.unsplash.com/photo-1594007654729-407eedc4be65?q=80&w=1928&auto=format&fit=crop', category: 'Pizza', isAvailable: true },
      { id: 102, name: 'Pasta Carbonara', description: 'Creamy pasta with bacon.', price: 15.50, image: 'https://images.unsplash.com/photo-1608797223204-a15d9c2a61da?q=80&w=1974&auto=format&fit=crop', category: 'Pasta', isAvailable: true },
      { id: 103, name: 'Tiramisu', description: 'Coffee-flavoured Italian dessert.', price: 7.00, image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?q=80&w=2072&auto=format&fit=crop', category: 'Desserts', isAvailable: true },
      { id: 104, name: 'Garlic Bread', description: 'Toasted bread with garlic butter.', price: 5.50, image: 'https://images.unsplash.com/photo-1623334055234-b2674e253c33?q=80&w=2070&auto=format&fit=crop', category: 'Sides', isAvailable: false },
      { id: 105, name: 'Pepperoni Pizza', description: 'Pizza with spicy pepperoni.', price: 14.50, image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?q=80&w=1981&auto=format&fit=crop', category: 'Pizza', isAvailable: true },
    ]
  },
  {
    id: 2, name: 'Spicy Dragon', cuisine: 'Chinese', rating: 4.5, deliveryTime: 30, image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=1974&auto=format&fit=crop',
    menu: [
      { id: 201, name: 'Sweet & Sour Chicken', description: 'Crispy chicken with sweet and sour sauce.', price: 14.00, image: 'https://images.unsplash.com/photo-1607329715180-8a4a7ff903c8?q=80&w=1935&auto=format&fit=crop', category: 'Main', isAvailable: true },
      { id: 202, name: 'Vegetable Fried Rice', description: 'Stir-fried rice with fresh vegetables.', price: 9.50, image: 'https://images.unsplash.com/photo-1616450257904-87d228b348d6?q=80&w=2070&auto=format&fit=crop', category: 'Sides', isAvailable: true },
      { id: 203, name: 'Spring Rolls', description: 'Crispy rolls with vegetable filling.', price: 6.00, image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?q=80&w=1974&auto=format&fit=crop', category: 'Appetizers', isAvailable: true },
      { id: 204, name: 'Kung Pao Shrimp', description: 'Spicy stir-fried shrimp with peanuts.', price: 16.50, image: 'https://images.unsplash.com/photo-1593921714848-a53c3b018b14?q=80&w=2070&auto=format&fit=crop', category: 'Main', isAvailable: false },
      { id: 205, name: 'Chow Mein Noodles', description: 'Stir-fried noodles with vegetables.', price: 12.00, image: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?q=80&w=1994&auto=format&fit=crop', category: 'Main', isAvailable: true },
    ]
  },
  {
    id: 3, name: 'Burger Barn', cuisine: 'American', rating: 4.7, deliveryTime: 20, image: 'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?q=80&w=2070&auto=format&fit=crop',
    menu: [
      { id: 301, name: 'Classic Cheeseburger', description: 'Beef patty with cheese, lettuce, and tomato.', price: 11.99, image: 'https://images.unsplash.com/photo-1551987840-f62d9c0252a2?q=80&w=2070&auto=format&fit=crop', category: 'Burgers', isAvailable: true },
      { id: 302, name: 'Loaded Fries', description: 'Fries with cheese, bacon, and sour cream.', price: 8.50, image: 'https://images.unsplash.com/photo-1598679253443-4b53b51b32b3?q=80&w=2070&auto=format&fit=crop', category: 'Sides', isAvailable: true },
      { id: 303, name: 'BBQ Bacon Burger', description: 'Beef patty with bacon, BBQ sauce, and onion rings.', price: 13.50, image: 'https://images.unsplash.com/photo-1607013251379-e6eecfffe234?q=80&w=1974&auto=format&fit=crop', category: 'Burgers', isAvailable: true },
      { id: 304, name: 'Chocolate Milkshake', description: 'Rich chocolate milkshake.', price: 6.00, image: 'https://images.unsplash.com/photo-1625862143015-88574775d713?q=80&w=1964&auto=format&fit=crop', category: 'Drinks', isAvailable: true },
    ]
  },
  {
    id: 4, name: 'Sushi Central', cuisine: 'Japanese', rating: 4.9, deliveryTime: 40, image: 'https://images.unsplash.com/photo-1579532537598-459ecdaf39cc?q=80&w=2070&auto=format&fit=crop',
    menu: [
      { id: 401, name: 'California Roll', description: 'Crab, avocado, and cucumber.', price: 10.00, image: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?q=80&w=2070&auto=format&fit=crop', category: 'Rolls', isAvailable: true },
      { id: 402, name: 'Salmon Nigiri', description: 'Fresh salmon over rice.', price: 5.00, image: 'https://images.unsplash.com/photo-1611142037388-a5951334c264?q=80&w=2070&auto=format&fit=crop', category: 'Nigiri', isAvailable: true },
      { id: 403, name: 'Spicy Tuna Roll', description: 'Tuna with spicy mayo.', price: 11.00, image: 'https://images.unsplash.com/photo-1622722234994-c13f8373f139?q=80&w=2070&auto=format&fit=crop', category: 'Rolls', isAvailable: true },
      { id: 404, name: 'Miso Soup', description: 'Traditional Japanese soup with tofu and seaweed.', price: 3.50, image: 'https://images.unsplash.com/photo-1569562211242-a396201b132e?q=80&w=1974&auto=format&fit=crop', category: 'Soups', isAvailable: true },
    ]
  },
  {
    id: 5, name: 'Taste of India', cuisine: 'Indian', rating: 4.9, deliveryTime: 35, image: 'https://images.unsplash.com/photo-1552566626-52f8b828add9?q=80&w=2070&auto=format&fit=crop',
    menu: [
      { id: 501, name: 'Chicken Biryani', description: 'Aromatic rice dish with chicken.', price: 15.99, image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?q=80&w=1974&auto=format&fit=crop', category: 'Main Courses', isAvailable: true },
      { id: 502, name: 'Paneer Butter Masala', description: 'Cottage cheese in a creamy tomato sauce.', price: 13.50, image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?q=80&w=2070&auto=format&fit=crop', category: 'Vegetarian', isAvailable: true },
      { id: 503, name: 'Garlic Naan', description: 'Soft flatbread with garlic.', price: 4.00, image: 'https://images.unsplash.com/photo-1631292784024-76b3a1a1b3a3?q=80&w=1974&auto=format&fit=crop', category: 'Breads', isAvailable: true },
      { id: 504, name: 'Samosa', description: 'Fried pastry with a savory filling.', price: 5.50, image: 'https://images.unsplash.com/photo-1625343114893-35f52174c203?q=80&w=2070&auto=format&fit=crop', category: 'Appetizers', isAvailable: false },
       { id: 505, name: 'Mango Lassi', description: 'Cool and refreshing yogurt drink.', price: 4.50, image: 'https://images.unsplash.com/photo-1567206563064-6f60f40a2b57?q=80&w=1974&auto=format&fit=crop', category: 'Drinks', isAvailable: true },
    ]
  },
];

export const ORDERS: Order[] = [
  { id: 1001, customerId: 1, restaurantId: 1, deliveryAgentId: 2, items: [{ menuItemId: 101, name: 'Margherita Pizza', quantity: 2, price: 12.99 }], total: 25.98, status: OrderStatus.DELIVERED, orderDate: '2023-10-26T10:00:00Z', deliveryAddress: '123 Green St, Cityville', isPreorder: false },
  { id: 1002, customerId: 1, restaurantId: 2, items: [{ menuItemId: 201, name: 'Sweet & Sour Chicken', quantity: 1, price: 14.00 }, { menuItemId: 202, name: 'Vegetable Fried Rice', quantity: 1, price: 9.50 }], total: 23.50, status: OrderStatus.OUT_FOR_DELIVERY, orderDate: new Date(Date.now() - 10 * 60000).toISOString(), deliveryAddress: '123 Green St, Cityville', isPreorder: false, deliveryAgentId: 2 },
  { id: 1003, customerId: 1, restaurantId: 3, items: [{ menuItemId: 301, name: 'Classic Cheeseburger', quantity: 1, price: 11.99 }], total: 11.99, status: OrderStatus.CONFIRMED, orderDate: '2023-10-27T12:00:00Z', deliveryAddress: '123 Green St, Cityville', isPreorder: true, scheduledDelivery: new Date(Date.now() + 24 * 3600 * 1000).toISOString() },
];

// SVG Icons
export const IconHome = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>;
export const IconHistory = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
export const IconShoppingCart = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>;
export const IconUser = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>;
export const IconLogout = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>;
export const IconDashboard = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>;
export const IconRestaurant = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 8v8m-4-4h8M10 21h4v-2h-4v2zM6 4h12l-2 5H8L6 4z" /></svg>;
export const IconTruck = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10l2 2h8a1 1 0 001-1z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10l2 2h8a1 1 0 001-1z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h2a1 1 0 001-1V7a1 1 0 00-1-1h-2" /></svg>;
export const IconList = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" /></svg>;
export const IconArrowLeft = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>;
export const IconMapPin = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
export const IconClock = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
export const IconStar = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>;
export const IconPlus = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>;
export const IconMinus = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 12H6" /></svg>;
export const IconChevronDown = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>;
export const IconSearch = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>;
export const IconCheckCircle = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
export const IconX = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>;
export const IconCalendar = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;